Macroscript ThePuppetTool 1.1 for 3dsmax 2010 (also works in 3dsmax 2008, 2009). Should work in 2012, 2013.

Cat/Biped selector with many powerful features, such as:

1. Automatically make Biped mathed current human CAT-rig
2. Paste opposite for human CAT-rig
3. Select All, select Opposite, easy select any bones of human characters by clicking on ImgTags (also with dbl-click, alt and ctrl of course)
4. Keys remover
5. Keys type changer

New in version 1.1
1. Added some tags and buttons to select more limbs
2. Increased selection performance
3. aam removed
4. sss added - selection sets

Installation:

1. Copy file ThePuppetTool.mcr and folder ThePuppetTool to max folder \UI\MacroScripts.
2. Run 3dsmax, go to Customize\Customize User Interface\Toolbars, and create new toolbar.
3. Select "ScriptAttack" from Category list and drag label "ThePuppetTool v1.1" to your toolbar. The button will be created there.
If you wish, you may drag the label to any standard toolbar without creating you own toolbar.


Note:
Keep in mind, Biped or Cat character have to be in your scene before you run the script, otherwise script will be closed automatically.



Enjoy						1acc